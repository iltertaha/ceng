/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_408()
{
    return 3285289288U;
}

unsigned getval_197()
{
    return 3251734856U;
}

unsigned addval_202(unsigned x)
{
    return x + 2417706058U;
}

void setval_409(unsigned *p)
{
    *p = 3285895496U;
}

void setval_349(unsigned *p)
{
    *p = 3267506504U;
}

void setval_273(unsigned *p)
{
    *p = 2445773128U;
}

unsigned getval_414()
{
    return 3632875740U;
}

unsigned addval_228(unsigned x)
{
    return x + 3285748040U;
}

void setval_250(unsigned *p)
{
    *p = 3281031259U;
}

void setval_464(unsigned *p)
{
    *p = 2425394267U;
}

unsigned getval_374()
{
    return 3285879112U;
}

void setval_195(unsigned *p)
{
    *p = 3269101896U;
}

unsigned addval_200(unsigned x)
{
    return x + 3284283720U;
}

unsigned addval_270(unsigned x)
{
    return x + 2446887240U;
}

unsigned addval_180(unsigned x)
{
    return x + 3285092680U;
}

void setval_351(unsigned *p)
{
    *p = 2430109960U;
}

void setval_237(unsigned *p)
{
    *p = 3515435096U;
}

unsigned getval_236()
{
    return 2496104776U;
}

unsigned addval_140(unsigned x)
{
    return x + 3666430163U;
}

unsigned addval_401(unsigned x)
{
    return x + 3281017830U;
}

void setval_149(unsigned *p)
{
    *p = 2428645704U;
}

unsigned getval_431()
{
    return 2429455176U;
}

void setval_412(unsigned *p)
{
    *p = 2462200136U;
}

unsigned addval_158(unsigned x)
{
    return x + 3285092680U;
}

unsigned getval_474()
{
    return 2428995912U;
}

unsigned getval_376()
{
    return 2428995912U;
}

unsigned addval_269(unsigned x)
{
    return x + 3285289224U;
}

unsigned getval_203()
{
    return 3285096776U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
